'use strict';

var audioData = [{
  'title': 'Part 1',
  'url': 'https://s3-eu-west-1.amazonaws.com/yasmeenbucket/The_Gruffalo_part2.mp3'
}];

module.exports = audioData;