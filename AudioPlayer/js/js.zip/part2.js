'use strict';

// Audio Source - AWS Podcast : https://aws.amazon.com/podcasts/aws-podcast/
var audioData = [{
  'title': 'Part 2',
  'url': 'https://s3-eu-west-1.amazonaws.com/yasmeenbucket/The_Gruffalo_part2.mp3'
}];

module.exports = audioData;